# Question Generation Experiment v3 - ADK Native

Clean, production-ready experiment framework for testing context-enriched question generation.

## Architecture

**ADK-Native Design:**
- Type-safe with Pydantic schemas
- Uses ADK's session services for persistence
- Sequential pipelines with BaseAgent and Agent
- All state tracked in ADK sessions

**Pipeline Flow:**
```
Context Builder (BaseAgent)
    ↓
Question Generator (Agent w/ LLM)
    ↓
Mock Genie Processor (BaseAgent)
    ↓
Results in State + Database
```

## Project Structure

```
experiment_v3/
├── schemas.py              # Type-safe Pydantic models
├── loaders.py              # Simple JSON loaders
├── pipeline.py             # Pipeline orchestration
├── agents/
│   ├── context_builder.py  # Context builder (BaseAgent)
│   ├── generator.py        # Question generator (Agent)
│   └── mock_genie.py       # Mock Genie processor (BaseAgent)
├── scripts/
│   ├── run_experiment.py   # Main experiment runner
│   └── export_to_excel.py  # Export results to Excel
├── data/
│   ├── contexts/           # Context JSON files
│   │   ├── sml/           # Metrics & dimensions
│   │   ├── personas/      # User persona cards
│   │   ├── patterns/      # BI pattern library
│   │   └── examples/      # Few-shot examples
│   ├── seed_questions/     # Test seed questions
│   └── outputs/            # Exported results
└── experiments.db          # SQLite (auto-created)
```

## Experiment Configurations

Tests 5 different levels of context enrichment:

1. **baseline** - No context, just LLM
2. **with_sml** - + SML catalog (metrics/dimensions)
3. **with_sml_persona** - + Persona card
4. **with_sml_persona_patterns** - + BI patterns library
5. **full_context** - + Few-shot examples

## Installation

```bash
pip install -r requirements.txt
```

## Usage

### Run Single Question

```bash
# Run all configs
python scripts/run_experiment.py "Why is margin for Category X down?"

# Run specific configs
python scripts/run_experiment.py "Why is margin down?" --configs baseline full_context

# Skip Genie processing
python scripts/run_experiment.py "Why is margin down?" --no-genie
```

### Run All Test Seeds

```bash
# Run all seeds from test_seeds.json
python scripts/run_experiment.py --all-seeds

# Run specific configs only
python scripts/run_experiment.py --all-seeds --configs baseline with_sml
```

### Export Results to Excel

```bash
# Export by run_id
python scripts/export_to_excel.py 20241121_143022

# Export to JSON instead
python scripts/export_to_excel.py 20241121_143022 --format json

# Export both formats
python scripts/export_to_excel.py 20241121_143022 --format both
```

### List Available Configs

```bash
python scripts/run_experiment.py --list-configs
```

## How It Works

### 1. Context Building (BaseAgent)

`ContextBuilderAgent` reads config from state and loads relevant context sources:

```python
# In state
context_config = {
    "sml_grounding": True,
    "persona_info": True,
    ...
}

# ContextBuilderAgent loads and creates ContextPacket
context_packet = {
    "sml": {...},
    "persona": {...},
    "patterns": [...],
    "examples": [...]
}

# Written back to state
state["context_packet"] = context_packet
```

### 2. Question Generation (Agent with LLM)

`create_generator_agent` creates an ADK Agent with Jinja2 template:

```python
# Template reads from state
{% if context_packet.sml %}
## Available Metrics
{% for metric in context_packet.sml.metrics %}
- {{ metric.name }}: {{ metric.description }}
{% endfor %}
{% endif %}

Generate plan for: {{ seed_question }}
```

ADK automatically:
1. Renders template with state variables
2. Calls LLM (Gemini)
3. Saves result to `state["question_plan"]` (via `output_key`)

### 3. Genie Processing (BaseAgent)

`MockGenieAgent` simulates processing questions through a Genie app:

```python
# Reads question_plan from state
# Generates mock GenieResult for each question
# Writes genie_results to state
```

### 4. Persistence

Everything is automatically persisted by ADK:
- State (context, plans, results) → SQLite
- Events (full conversation log) → SQLite
- Retrievable by session_id

## Type Safety

All state conforms to Pydantic schemas in `schemas.py`:

```python
class ExperimentState(BaseModel):
    seed_question: str
    run_id: str
    config_name: str
    context_config: ContextConfig
    context_packet: Optional[ContextPacket]
    question_plan: Optional[QuestionPlan]
    genie_results: Optional[List[GenieResult]]
    ...

# Validate state anytime
state_obj = ExperimentState(**session.state)
```

## Excel Export

The export script aggregates results into a flat table:

| run_id | config_name | seed_question | question_text | genie_status | ... |
|--------|-------------|---------------|---------------|--------------|-----|
| 20241121_143022 | baseline | Why is margin down? | Show margin trend | success | ... |
| 20241121_143022 | full_context | Why is margin down? | Break down by category | success | ... |

Each question gets its own row with:
- Experiment metadata (run_id, config, model)
- Seed question
- Generated question details
- Genie processing results
- Context flags

## Development

### Adding New Context Sources

1. Add JSON file to `data/contexts/<source>/`
2. Add loader function to `loaders.py`
3. Add flag to `ContextConfig` in `schemas.py`
4. Update `ContextBuilderAgent` to load when enabled
5. Update generator template to use new context

### Adding Custom Agents

Create a new agent in `agents/`:

```python
from google.adk.agents import BaseAgent
from google.adk.events import Event, EventActions

class MyCustomAgent(BaseAgent):
    async def _run_async_impl(self, ctx):
        # Read from state
        data = ctx.session.state["my_input"]
        
        # Custom logic
        result = process(data)
        
        # Write to state
        yield Event(
            author=self.name,
            actions=EventActions(
                state_delta={"my_output": result}
            )
        )
```

Add to pipeline in `pipeline.py`:

```python
sub_agents.append(MyCustomAgent())
```

## Key Design Principles

1. **ADK-Native** - Use ADK's built-in features, don't fight them
2. **Type-Safe** - Pydantic schemas for all state
3. **Simple** - Functions and agents, minimal abstractions
4. **Composable** - Agents are building blocks
5. **Observable** - Everything in state, queryable in DB

## Troubleshooting

**Import errors:**
```bash
pip install --upgrade google-adk pydantic openpyxl
```

**No results in Excel:**
- Check run_id is correct
- Check database has sessions: `sqlite3 experiments.db "SELECT * FROM sessions"`

**Generation errors:**
- Check context JSON files exist
- Check API credentials for Gemini
- Enable ADK logging for debug info

## Next Steps

1. Replace mock Genie with real Genie client
2. Add evaluation metrics
3. Add more context sources (docs, history)
4. Add parallel pattern sampling
5. Add result analysis and visualization

---

Built with ❤️ using Google ADK
