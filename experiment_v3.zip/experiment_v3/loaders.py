"""
Simple data loaders - just functions that return dicts.

No classes, no abstractions. Load JSON → return dict.
"""

import json
from pathlib import Path
from typing import Dict, List, Any, Optional


DATA_DIR = Path(__file__).parent / "data" / "contexts"


def load_sml(filter_keywords: Optional[List[str]] = None) -> Dict[str, Any]:
    """Load SML catalog. Optionally filter by keywords."""
    with open(DATA_DIR / "sml" / "metrics.json") as f:
        data = json.load(f)
    
    if filter_keywords:
        # Simple keyword filtering
        keywords_lower = [k.lower() for k in filter_keywords]
        filtered_metrics = [
            m for m in data["metrics"]
            if any(kw in m["name"].lower() or 
                   kw in m.get("description", "").lower() or
                   any(kw in str(t).lower() for t in m.get("tags", []))
                   for kw in keywords_lower)
        ]
        data["metrics"] = filtered_metrics[:5]  # Top 5
        data["dimensions"] = data["dimensions"][:5]  # Top 5
    
    return data


def load_persona(name: str = "merch_finance_analyst") -> Dict[str, Any]:
    """Load persona card."""
    with open(DATA_DIR / "personas" / f"{name}.json") as f:
        return json.load(f)


def load_patterns() -> List[Dict[str, Any]]:
    """Load BI pattern library."""
    with open(DATA_DIR / "patterns" / "bi_moves.json") as f:
        return json.load(f)["patterns"]


def load_examples(max_count: int = 3) -> List[Dict[str, Any]]:
    """Load few-shot examples."""
    with open(DATA_DIR / "examples" / "question_plans.json") as f:
        return json.load(f)["examples"][:max_count]


def load_seed_questions() -> List[Dict[str, Any]]:
    """Load seed questions for testing."""
    seed_file = Path(__file__).parent / "data" / "seed_questions" / "test_seeds.json"
    with open(seed_file) as f:
        return json.load(f)["seed_questions"]
