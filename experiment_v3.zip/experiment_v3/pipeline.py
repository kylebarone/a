"""
Experiment Pipeline - Full Orchestration

Runs complete experiment pipeline:
1. Context Builder (if needed)
2. Question Generator  
3. Mock Genie Processing

All using ADK's SequentialAgent for clean orchestration.
"""

import json
import uuid
from datetime import datetime
from typing import Optional, Tuple

from google.adk import Runner
from google.adk.agents import SequentialAgent
from google.adk.services import DatabaseSessionService

from schemas import (
    GeneratorConfig, 
    QuestionPlan, 
    create_initial_state,
    ExperimentState
)
from agents.context_builder import ContextBuilderAgent
from agents.generator import create_generator_agent
from agents.mock_genie import MockGenieAgent


async def run_experiment(
    seed_question: str,
    config: GeneratorConfig,
    run_id: str,
    db_path: str = "experiments.db",
    run_genie: bool = True
) -> Tuple[str, ExperimentState]:
    """
    Run complete experiment pipeline.
    
    Args:
        seed_question: The seed question
        config: Generator configuration
        run_id: Experiment run ID
        db_path: Path to SQLite database
        run_genie: Whether to run mock Genie processing
    
    Returns:
        (session_id, final_state) tuple
    """
    # Create initial state
    initial_state = create_initial_state(seed_question, config, run_id)
    initial_state["num_questions"] = config.num_questions
    
    # Build pipeline based on config
    sub_agents = []
    
    # Add context builder if any context is enabled
    has_context = any([
        config.context_config.sml_grounding,
        config.context_config.persona_info,
        config.context_config.pattern_library,
        config.context_config.few_shot_examples
    ])
    
    if has_context:
        sub_agents.append(ContextBuilderAgent())
    
    # Add generator
    generator = create_generator_agent(config.name, config.model)
    sub_agents.append(generator)
    
    # Add mock Genie if requested
    if run_genie:
        sub_agents.append(MockGenieAgent())
    
    # Create pipeline
    pipeline = SequentialAgent(
        name=f"pipeline_{config.name}",
        sub_agents=sub_agents
    )
    
    # Create runner
    runner = Runner(
        app_name="question_experiment",
        agent=pipeline,
        session_service=DatabaseSessionService(f"sqlite:///{db_path}")
    )
    
    # Run pipeline
    session_id = f"{run_id}_{config.name}_{uuid.uuid4().hex[:8]}"
    
    async for event in runner.run_async(
        user_id="experiment",
        session_id=session_id,
        new_message=seed_question,
        initial_state=initial_state
    ):
        # Events are logged automatically by ADK
        pass
    
    # Retrieve final state
    session = await runner.session_service.get_session(
        app_name="question_experiment",
        user_id="experiment",
        session_id=session_id
    )
    
    final_state = ExperimentState(**session.state)
    
    return session_id, final_state


async def parse_and_validate_plan(state: ExperimentState) -> Optional[QuestionPlan]:
    """
    Parse and validate the question plan from state.
    
    Handles JSON parsing and markdown cleanup.
    """
    if not state.question_plan:
        return None
    
    # If it's already a dict, validate it
    if isinstance(state.question_plan, dict):
        return QuestionPlan(**state.question_plan)
    
    # If it's a string, try to parse it
    if isinstance(state.question_plan, str):
        text = state.question_plan.strip()
        
        # Clean markdown
        if text.startswith('```'):
            text = text.split('```')[1]
            if text.startswith('json'):
                text = text[4:]
            text = text.split('```')[0].strip()
        
        # Parse JSON
        try:
            plan_dict = json.loads(text)
            return QuestionPlan(**plan_dict)
        except json.JSONDecodeError:
            return None
    
    return None
