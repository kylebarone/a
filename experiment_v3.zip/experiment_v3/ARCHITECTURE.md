# Technical Architecture - Experiment v3

## Overview

Clean, ADK-native experiment framework for testing context-enriched question generation with full observability and type safety.

---

## Core Design Principles

### 1. ADK-Native Architecture

**Don't fight the framework - use its features:**

- ✅ **State Management**: Use `session.state` for all data
- ✅ **Jinja2 Templates**: Use built-in template rendering
- ✅ **output_key**: Auto-save LLM outputs to state
- ✅ **Event Streaming**: Natural async communication
- ✅ **Session Services**: Built-in persistence

**Not:**
- ❌ Custom context builders with complex classes
- ❌ Manual prompt string concatenation
- ❌ External state management
- ❌ Custom serialization

### 2. Type Safety with Pydantic

**Every state dict has a schema:**

```python
class ExperimentState(BaseModel):
    seed_question: str
    run_id: str
    context_packet: Optional[ContextPacket]
    question_plan: Optional[QuestionPlan]
    genie_results: Optional[List[GenieResult]]
    ...

# Validate anytime
state_obj = ExperimentState(**session.state)
```

**Benefits:**
- IDE autocomplete works
- Catch errors early
- Self-documenting code
- Easy to refactor

### 3. Agent vs BaseAgent

**Use the right tool:**

```python
# Agent - When you need LLM reasoning
generator = Agent(
    name="generator",
    model="gemini-2.0-flash-exp",
    instruction="..."  # Jinja2 template
)

# BaseAgent - When you need custom logic
class ContextBuilder(BaseAgent):
    async def _run_async_impl(self, ctx):
        # Pure Python logic
        data = load_files()
        yield Event(...)
```

**When to use:**
- `Agent` → Generation, classification, extraction (LLM tasks)
- `BaseAgent` → Loading, filtering, routing, calculations (Python tasks)

### 4. Composition over Complexity

**Build complex workflows from simple agents:**

```python
# Each agent does ONE thing well
pipeline = SequentialAgent(
    sub_agents=[
        ContextBuilderAgent(),      # Load context
        create_generator_agent(),    # Generate questions
        MockGenieAgent()             # Process questions
    ]
)
```

**Not:**
- One giant agent that does everything
- Complex inheritance hierarchies
- Tight coupling between components

---

## Architecture Layers

### Layer 1: Data (JSON Files)

```
data/contexts/
  sml/metrics.json          ← Semantic model
  personas/*.json           ← User profiles
  patterns/bi_moves.json    ← Analysis patterns
  examples/*.json           ← Few-shot examples
```

**Simple, versionable, human-readable**

### Layer 2: Loaders (Pure Functions)

```python
# loaders.py
def load_sml() -> Dict[str, Any]:
    with open("...") as f:
        return json.load(f)
```

**No classes, no state, just functions that return dicts**

### Layer 3: Schemas (Pydantic Models)

```python
# schemas.py
class ContextPacket(BaseModel):
    sml: Optional[Dict]
    persona: Optional[Dict]
    patterns: Optional[List]
    ...

class ExperimentState(BaseModel):
    seed_question: str
    context_packet: Optional[ContextPacket]
    question_plan: Optional[QuestionPlan]
    ...
```

**Type-safe contracts for all state**

### Layer 4: Agents (ADK Components)

```python
# agents/
context_builder.py    ← BaseAgent (load context)
generator.py          ← Agent (LLM generation)
mock_genie.py         ← BaseAgent (simulate processing)
```

**Each agent reads from state, does work, writes to state**

### Layer 5: Pipeline (Orchestration)

```python
# pipeline.py
async def run_experiment(seed, config):
    # Build pipeline based on config
    pipeline = SequentialAgent(sub_agents=[...])
    
    # Run with initial state
    await runner.run_async(initial_state=...)
```

**Composes agents into workflows**

### Layer 6: Scripts (CLI/API)

```python
# scripts/
run_experiment.py     ← Run experiments
export_to_excel.py    ← Export results
```

**User-facing interfaces**

---

## Data Flow

### 1. Initialization

```
User Input:
  seed_question = "Why is margin down?"
  config = GeneratorConfig(name="full_context", ...)

↓

create_initial_state():
  {
    "seed_question": "Why is margin down?",
    "run_id": "20241122_093045",
    "config_name": "full_context",
    "context_config": {...},
    "num_questions": 5
  }
```

### 2. Context Building (If Enabled)

```
ContextBuilderAgent reads state:
  - context_config.sml_grounding = True
  - context_config.persona_info = True
  - seed_question = "Why is margin down?"

↓

Loads files:
  - load_sml(keywords=["margin", "down"])
  - load_persona()

↓

Creates ContextPacket:
  {
    "sml": {metrics: [...], dimensions: [...]},
    "persona": {name: "...", cares_about: [...]}
  }

↓

Writes to state:
  state["context_packet"] = packet
```

### 3. Question Generation

```
Agent with Jinja2 template reads state:
  - seed_question
  - num_questions
  - context_packet (if exists)

↓

ADK renders template:
  "Available Metrics: {{ context_packet.sml.metrics }}"
  → "Available Metrics: gross_margin, gmv, ..."

↓

Sends to LLM:
  [Rendered prompt with context]

↓

LLM responds:
  {
    "anchor_question": "Why is margin down?",
    "questions": [...]
  }

↓

ADK saves to state (via output_key):
  state["question_plan"] = response
```

### 4. Genie Processing

```
MockGenieAgent reads state:
  - question_plan.questions = [q1, q2, q3, ...]

↓

Processes each question:
  - Generates mock steps
  - Creates GenieResult

↓

Writes to state:
  state["genie_results"] = [result1, result2, ...]
```

### 5. Persistence

```
ADK automatically:
  - Saves state to SQLite
  - Saves events to SQLite
  - Links by session_id

↓

Queryable later:
  session = await session_service.get_session(session_id)
  plan = session.state["question_plan"]
```

---

## State Evolution

**State grows through pipeline:**

```python
# Initial
{
  "seed_question": "...",
  "run_id": "...",
  "config_name": "...",
  "context_config": {...}
}

# After ContextBuilder
{
  ...above,
  "context_packet": {...}
}

# After Generator
{
  ...above,
  "question_plan": {...}
}

# After MockGenie
{
  ...above,
  "genie_results": [...]
}

# All in ExperimentState schema!
```

---

## Configuration System

### Config Hierarchy

```python
ContextConfig (what context to include)
    ↓
GeneratorConfig (full config)
    ↓
Pipeline Decision (which agents)
    ↓
initial_state (input to pipeline)
```

### Config → Pipeline Mapping

```python
config.context_config = ContextConfig(
    sml_grounding=True,
    persona_info=True
)

↓

Pipeline:
  sub_agents = [
    ContextBuilderAgent(),  # Added because context needed
    create_generator_agent(),
    MockGenieAgent()
  ]

↓

ContextBuilder reads config and loads:
  - SML ✅
  - Persona ✅
  - Patterns ❌
  - Examples ❌
```

---

## Key Implementation Details

### Jinja2 Template Rendering

**ADK automatically fills {{ variables }} from state:**

```python
instruction = """
{% if context_packet.sml %}
Metrics: {{ context_packet.sml.metrics }}
{% endif %}

Question: {{ seed_question }}
"""

# ADK renders with state
state = {
  "context_packet": {"sml": {...}},
  "seed_question": "Why is margin down?"
}

# Result:
# "Metrics: [...]
#  Question: Why is margin down?"
```

### Event-Based Communication

**Agents communicate via events:**

```python
yield Event(
    author=self.name,
    content={"parts": [{"text": "Done"}]},
    actions=EventActions(
        state_delta={"my_key": my_value}
    )
)

# ADK updates state:
# session.state["my_key"] = my_value
```

### Async Generators

**All agents are async generators:**

```python
async def _run_async_impl(self, ctx):
    # Can yield multiple events
    yield Event(...)  # Progress update
    yield Event(...)  # Another update
    yield Event(...)  # Final result
```

---

## Testing Strategy

### Unit Tests

**Test components in isolation:**

```python
# Test loaders
def test_load_sml():
    data = load_sml()
    assert "metrics" in data

# Test schemas
def test_context_packet():
    packet = ContextPacket(sml={...})
    assert packet.builder_type == "simple"
```

### Integration Tests

**Test agents with mock state:**

```python
async def test_context_builder():
    agent = ContextBuilderAgent()
    ctx = MockContext(state={
        "context_config": {"sml_grounding": True},
        "seed_question": "test"
    })
    
    events = [e async for e in agent.run_async(ctx)]
    assert "context_packet" in events[-1].actions.state_delta
```

### End-to-End Tests

**Test full pipeline:**

```python
async def test_full_pipeline():
    result = await run_experiment(
        seed_question="Why is margin down?",
        config=GeneratorConfig(name="test"),
        run_id="test_123"
    )
    
    assert result.question_plan is not None
    assert len(result.genie_results) > 0
```

---

## Extension Points

### Add New Context Source

1. **Add JSON file**: `data/contexts/my_source/data.json`
2. **Add loader**: `loaders.py::load_my_source()`
3. **Add flag**: `schemas.py::ContextConfig.my_source`
4. **Update builder**: `context_builder.py::_run_async_impl()`
5. **Update template**: `generator.py::INSTRUCTION_TEMPLATE`

### Add New Agent

```python
# agents/my_agent.py
class MyAgent(BaseAgent):
    async def _run_async_impl(self, ctx):
        input_data = ctx.session.state["input"]
        result = process(input_data)
        yield Event(
            author=self.name,
            actions=EventActions(
                state_delta={"output": result}
            )
        )

# Add to pipeline
sub_agents.append(MyAgent())
```

### Add New Export Format

```python
# scripts/export_to_excel.py
def export_to_csv(rows, output_path):
    # Your CSV export logic
    pass

# Add CLI option
parser.add_argument("--format", choices=["excel", "json", "csv"])
```

---

## Performance Considerations

### Caching

**ADK sessions are cached:**
- State is loaded once per run
- Events are streamed
- Database writes are batched

### Parallelization

**Use ParallelAgent for concurrent processing:**

```python
parallel = ParallelAgent(
    sub_agents=[
        generator1,
        generator2,
        generator3
    ]
)

# All run concurrently
```

### Database Optimization

**SQLite is fine for experiments:**
- ~100 sessions: < 10 MB
- Queries are fast (indexed)
- Easy to inspect/debug

**For production:**
- Use PostgreSQL
- Batch writes
- Add indexes

---

## Debugging

### View State

```python
# After run
session = await session_service.get_session(session_id)
print(session.state)
```

### View Events

```python
for event in session.events:
    print(f"{event.author}: {event.content}")
```

### Query Database

```bash
sqlite3 experiments.db

sqlite> SELECT * FROM sessions WHERE id LIKE '%20241122%';
sqlite> SELECT json_extract(state, '$.config_name') FROM sessions;
```

### Enable Logging

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

---

## Summary

**This architecture is:**
- ✅ Simple (functions + agents)
- ✅ Type-safe (Pydantic everywhere)
- ✅ Observable (everything in state/DB)
- ✅ Composable (agents are building blocks)
- ✅ ADK-native (uses framework features)
- ✅ Extensible (clear extension points)

**It avoids:**
- ❌ Over-abstraction
- ❌ Tight coupling
- ❌ Hidden state
- ❌ Complex inheritance
- ❌ Fighting the framework

**Perfect for:**
- Rapid experimentation
- A/B testing different approaches
- Collecting training data
- Building agent workflows

---

**Questions? Check README.md and QUICKSTART.md**
