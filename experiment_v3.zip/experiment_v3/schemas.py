"""
Type-safe state schemas for the experiment.

All state in ADK sessions conforms to these Pydantic models.
This makes state visible, type-safe, and easy to work with.
"""

from typing import List, Optional, Dict, Any, Literal
from pydantic import BaseModel, Field
from datetime import datetime


# ============================================================================
# Context Configuration
# ============================================================================

class ContextConfig(BaseModel):
    """Configuration for what context to include."""
    
    sml_grounding: bool = Field(False, description="Include SML catalog")
    persona_info: bool = Field(False, description="Include persona card")
    pattern_library: bool = Field(False, description="Include BI patterns")
    few_shot_examples: bool = Field(False, description="Include examples")


class UserScope(BaseModel):
    """User's domain and role context."""
    
    role: str = Field(default="finance_analyst", description="User role")
    domain: str = Field(default="merchandising_finance", description="Domain")


# ============================================================================
# Context Packets (Type-Safe Context Data)
# ============================================================================

class ContextPacket(BaseModel):
    """
    A built context packet - type-safe container for context data.
    
    This goes in state and is used by generators.
    """
    
    # What pattern this packet is for
    pattern: Optional[str] = Field(None, description="Pattern name if pattern-specific")
    
    # Context data (stored as dicts for flexibility)
    sml: Optional[Dict[str, Any]] = Field(None, description="SML subset")
    persona: Optional[Dict[str, Any]] = Field(None, description="Persona card")
    patterns: Optional[List[Dict[str, Any]]] = Field(None, description="Pattern library")
    examples: Optional[List[Dict[str, Any]]] = Field(None, description="Few-shot examples")
    
    # Metadata
    built_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    builder_type: str = Field(default="simple", description="Which builder created this")


# ============================================================================
# Question Plans (Output)
# ============================================================================

class Question(BaseModel):
    """A single analytical question."""
    
    text: str = Field(..., description="Question text")
    perspectives: List[str] = Field(default_factory=list)
    moves: List[str] = Field(default_factory=list)
    priority: Optional[int] = Field(None, description="1=high, 2=med, 3=low")


class QuestionPlan(BaseModel):
    """Complete question plan output."""
    
    anchor_question: str
    lens: str = "Merchandising Finance Analyst"
    mode: Literal["breakdown", "expansion"] = "breakdown"
    questions: List[Question]
    metadata: Dict[str, Any] = Field(default_factory=dict)


# ============================================================================
# Genie Results (Mock)
# ============================================================================

class GenieStep(BaseModel):
    """A single Genie processing step."""
    
    step_num: int
    query: str
    result_summary: str
    status: Literal["success", "error"] = "success"
    duration_ms: float = 0.0


class GenieResult(BaseModel):
    """Result from processing a question through Genie."""
    
    question_text: str
    session_id: str
    steps: List[GenieStep]
    total_duration_ms: float
    status: Literal["success", "partial", "error"] = "success"
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


# ============================================================================
# Complete Experiment State (Type-Safe)
# ============================================================================

class ExperimentState(BaseModel):
    """
    Complete state schema for experiment.
    
    This is what's in session.state at any given time.
    Makes state visible and type-safe!
    """
    
    # ========== Inputs ==========
    seed_question: str = Field(..., description="The seed question")
    run_id: str = Field(..., description="Experiment run ID")
    config_name: str = Field(..., description="Config being tested")
    
    user_scope: UserScope = Field(default_factory=UserScope)
    context_config: ContextConfig = Field(default_factory=ContextConfig)
    
    # ========== Context Building ==========
    context_packet: Optional[ContextPacket] = Field(
        None,
        description="Built context"
    )
    
    # ========== Generation ==========
    question_plan: Optional[QuestionPlan] = Field(
        None,
        description="Generated question plan"
    )
    
    # ========== Genie Processing ==========
    genie_results: Optional[List[GenieResult]] = Field(
        None,
        description="Results from Genie processing each question"
    )
    
    # ========== Metadata ==========
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    model: str = Field(default="gemini-2.0-flash-exp")
    generator_type: str = Field(default="baseline", description="baseline or context")


# ============================================================================
# Generator Configurations
# ============================================================================

class GeneratorConfig(BaseModel):
    """Configuration for a question generator."""
    
    name: str = Field(..., description="Config name")
    model: str = Field(default="gemini-2.0-flash-exp")
    context_config: ContextConfig = Field(default_factory=ContextConfig)
    num_questions: int = Field(default=5)


def get_all_configs() -> Dict[str, GeneratorConfig]:
    """Get all predefined experiment configurations."""
    return {
        "baseline": GeneratorConfig(
            name="baseline",
            context_config=ContextConfig()  # All False - no context
        ),
        "with_sml": GeneratorConfig(
            name="with_sml",
            context_config=ContextConfig(sml_grounding=True)
        ),
        "with_sml_persona": GeneratorConfig(
            name="with_sml_persona",
            context_config=ContextConfig(
                sml_grounding=True,
                persona_info=True
            )
        ),
        "with_sml_persona_patterns": GeneratorConfig(
            name="with_sml_persona_patterns",
            context_config=ContextConfig(
                sml_grounding=True,
                persona_info=True,
                pattern_library=True
            )
        ),
        "full_context": GeneratorConfig(
            name="full_context",
            context_config=ContextConfig(
                sml_grounding=True,
                persona_info=True,
                pattern_library=True,
                few_shot_examples=True
            )
        )
    }


# ============================================================================
# Helpers for working with typed state
# ============================================================================

def validate_state(state: Dict[str, Any]) -> ExperimentState:
    """
    Validate state dict against schema.
    
    Use this to get type-safe access to state.
    """
    return ExperimentState(**state)


def create_initial_state(
    seed_question: str,
    config: GeneratorConfig,
    run_id: str
) -> Dict[str, Any]:
    """
    Create initial state dict for experiment.
    
    Returns dict ready for runner.run_async(initial_state=...)
    """
    # Determine generator type
    has_context = any([
        config.context_config.sml_grounding,
        config.context_config.persona_info,
        config.context_config.pattern_library,
        config.context_config.few_shot_examples
    ])
    
    state = ExperimentState(
        seed_question=seed_question,
        run_id=run_id,
        config_name=config.name,
        user_scope=UserScope(),
        context_config=config.context_config,
        model=config.model,
        generator_type="context" if has_context else "baseline"
    )
    
    return state.model_dump()
