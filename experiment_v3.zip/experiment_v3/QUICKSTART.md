# Quick Start Guide - Experiment v3

## 🚀 Get Running in 3 Steps

### 1. Install Dependencies

```bash
cd experiment_v3
pip install -r requirements.txt
```

### 2. Run Your First Experiment

```bash
# Test single question across all configs
python scripts/run_experiment.py "Why is margin for Category X down?"
```

You'll see:
```
==================================================
Question Generation Experiment
==================================================
Run ID: 20241122_093045
Seed: Why is margin for Category X down?
Configs: 5
Genie Processing: Enabled
==================================================

Running baseline... ✓ (5 questions, 5 genie results)
Running with_sml... ✓ (5 questions, 5 genie results)
Running with_sml_persona... ✓ (5 questions, 5 genie results)
Running with_sml_persona_patterns... ✓ (5 questions, 5 genie results)
Running full_context... ✓ (5 questions, 5 genie results)

Summary
==================================================
Total runs: 5
Successful: 5
Failed: 0

Results saved to: data/outputs/results_20241122_093045.json
Run ID: 20241122_093045
```

### 3. Export to Excel

```bash
# Use the run_id from step 2
python scripts/export_to_excel.py 20241122_093045
```

You'll get an Excel file in `data/outputs/` with all results!

---

## 📊 Run All Test Seeds

```bash
# Run all 5 seeds from test_seeds.json
python scripts/run_experiment.py --all-seeds
```

This runs all 5 configs × 5 seeds = 25 total generations.

---

## 🎯 Mission Checklist (For Tomorrow)

### ✅ A. Question Generation Works

- [x] Baseline generator runs
- [x] Context generator runs  
- [x] Single command generates both
- [x] Metadata tracked (run_id, config, generator_type)
- [x] Questions persisted in ADK sessions

**Test it:**
```bash
python scripts/run_experiment.py "Why is margin down?" --configs baseline full_context
```

### ✅ B. Questions → Genie App

- [x] Mock Genie processes each question
- [x] Session records created with linkage
- [x] Results stored with run_id, question_id, etc.

**Test it:**
```bash
# Default runs with Genie
python scripts/run_experiment.py "Why is margin down?"

# Skip Genie if needed
python scripts/run_experiment.py "Why is margin down?" --no-genie
```

### ✅ C. Aggregation → Excel

- [x] Aggregator loads sessions
- [x] Joins questions + genie results
- [x] Excel export with all columns

**Test it:**
```bash
# After running experiment with run_id 20241122_093045
python scripts/export_to_excel.py 20241122_093045
```

---

## 🔧 Common Commands

### List Available Configs
```bash
python scripts/run_experiment.py --list-configs
```

### Run Specific Configs Only
```bash
python scripts/run_experiment.py --all-seeds --configs baseline with_sml full_context
```

### Export to JSON Instead
```bash
python scripts/export_to_excel.py 20241122_093045 --format json
```

### Export Both Formats
```bash
python scripts/export_to_excel.py 20241122_093045 --format both
```

---

## 📁 What Gets Created

### Databases
- `experiments.db` - SQLite database with all sessions

### Output Files
- `data/outputs/results_<run_id>.json` - JSON summary per run
- `data/outputs/experiment_<run_id>_<timestamp>.xlsx` - Excel export

### What's in the Database
Each session contains:
- **State**: seed_question, context_packet, question_plan, genie_results
- **Events**: Full conversation log
- **Metadata**: run_id, config_name, timestamps

---

## 🎨 Customization

### Test Your Own Questions

Edit `data/seed_questions/test_seeds.json`:
```json
{
  "seed_questions": [
    {
      "id": "my_q1",
      "seed_question": "Your question here?",
      "domain": "merchandising_finance",
      "user_persona": "Merchandising Finance Analyst",
      "expected_mode": "breakdown"
    }
  ]
}
```

Then run:
```bash
python scripts/run_experiment.py --all-seeds
```

### Change Number of Questions

In `schemas.py`, modify `GeneratorConfig`:
```python
num_questions: int = Field(default=10)  # Change from 5 to 10
```

### Add More Context

Add new JSON files to `data/contexts/<source>/` and update loaders.

---

## 💡 Tips

1. **Start small**: Test one question first
2. **Check run_id**: You'll need it for exporting
3. **Excel is formatted**: Headers, auto-sized columns, frozen pane
4. **State is type-safe**: Pydantic validates everything
5. **Everything is logged**: Check `experiments.db` for debugging

---

## 🐛 If Something Breaks

### Check ADK Installation
```bash
pip show google-adk
```

### Check Database
```bash
sqlite3 experiments.db "SELECT * FROM sessions LIMIT 5"
```

### Enable Debug Logging
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Check Context Files
```bash
ls -la data/contexts/*/*.json
```

---

## 📈 Next Steps

1. ✅ Replace mock Genie with real client
2. ✅ Add evaluation metrics (coverage, relevance)
3. ✅ Visualize results (charts in Excel)
4. ✅ A/B test different prompts
5. ✅ Add more context sources

---

**You're all set! Run your first experiment now! 🎉**
