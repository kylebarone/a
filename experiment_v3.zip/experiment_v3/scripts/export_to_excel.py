#!/usr/bin/env python3
"""
Excel Export - Aggregate and Export Experiment Results

Loads results from ADK sessions and exports to Excel for analysis.
"""

import asyncio
import sys
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime
import json

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from google.adk.services import DatabaseSessionService
from schemas import ExperimentState, QuestionPlan, GenieResult
from pipeline import parse_and_validate_plan

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False
    print("Warning: openpyxl not installed. Install with: pip install openpyxl")


async def load_experiment_sessions(
    run_id_prefix: str,
    db_path: str = "experiments.db"
) -> List[Dict[str, Any]]:
    """
    Load all sessions for an experiment run.
    
    Args:
        run_id_prefix: Run ID or prefix to filter sessions
        db_path: Path to SQLite database
    
    Returns:
        List of session data dicts
    """
    session_service = DatabaseSessionService(f"sqlite:///{db_path}")
    
    # List all sessions
    sessions = await session_service.list_sessions(
        app_name="question_experiment",
        user_id="experiment"
    )
    
    # Filter by run_id
    filtered_sessions = [
        s for s in sessions
        if run_id_prefix in s.id
    ]
    
    # Load full session data
    session_data = []
    
    for session in filtered_sessions:
        try:
            state = ExperimentState(**session.state)
            plan = await parse_and_validate_plan(state)
            
            session_data.append({
                "session_id": session.id,
                "state": state,
                "plan": plan,
                "events": session.events
            })
        except Exception as e:
            print(f"Warning: Could not load session {session.id}: {e}")
    
    return session_data


def aggregate_results(session_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Aggregate session data into flat rows for Excel.
    
    Each question gets its own row with full context.
    """
    rows = []
    
    for session in session_data:
        state: ExperimentState = session["state"]
        plan: QuestionPlan = session["plan"]
        
        if not plan:
            continue
        
        # One row per question
        for i, question in enumerate(plan.questions, 1):
            # Find corresponding Genie result if exists
            genie_result = None
            if state.genie_results and i - 1 < len(state.genie_results):
                genie_result = GenieResult(**state.genie_results[i - 1])
            
            row = {
                # Experiment metadata
                "run_id": state.run_id,
                "config_name": state.config_name,
                "generator_type": state.generator_type,
                "model": state.model,
                "session_id": session["session_id"],
                
                # Seed question
                "seed_question": state.seed_question,
                
                # Generated question
                "question_num": i,
                "question_text": question.text,
                "perspectives": ", ".join(question.perspectives),
                "moves": ", ".join(question.moves),
                "priority": question.priority,
                
                # Genie results
                "genie_session_id": genie_result.session_id if genie_result else "",
                "genie_num_steps": len(genie_result.steps) if genie_result else 0,
                "genie_duration_ms": genie_result.total_duration_ms if genie_result else 0,
                "genie_status": genie_result.status if genie_result else "",
                
                # Context info
                "has_sml": state.context_config.sml_grounding,
                "has_persona": state.context_config.persona_info,
                "has_patterns": state.context_config.pattern_library,
                "has_examples": state.context_config.few_shot_examples,
                
                # Timestamps
                "timestamp": state.timestamp
            }
            
            rows.append(row)
    
    return rows


def export_to_excel(
    rows: List[Dict[str, Any]],
    output_path: Path
):
    """
    Export aggregated rows to Excel with formatting.
    
    Args:
        rows: List of row dicts
        output_path: Path to save Excel file
    """
    if not EXCEL_AVAILABLE:
        raise ImportError("openpyxl is required for Excel export")
    
    # Create workbook
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Experiment Results"
    
    # Define columns
    columns = [
        "run_id", "config_name", "generator_type", "model",
        "seed_question", "question_num", "question_text",
        "perspectives", "moves", "priority",
        "genie_session_id", "genie_num_steps", "genie_duration_ms", "genie_status",
        "has_sml", "has_persona", "has_patterns", "has_examples",
        "session_id", "timestamp"
    ]
    
    # Header row
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")
    
    for col_idx, col_name in enumerate(columns, 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.value = col_name
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")
    
    # Data rows
    for row_idx, row_data in enumerate(rows, 2):
        for col_idx, col_name in enumerate(columns, 1):
            ws.cell(row=row_idx, column=col_idx).value = row_data.get(col_name, "")
    
    # Auto-size columns
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width
    
    # Freeze header row
    ws.freeze_panes = "A2"
    
    # Save
    wb.save(output_path)
    print(f"Exported to: {output_path}")


def export_to_json(
    rows: List[Dict[str, Any]],
    output_path: Path
):
    """Export aggregated rows to JSON."""
    with open(output_path, 'w') as f:
        json.dump(rows, f, indent=2)
    
    print(f"Exported to: {output_path}")


async def export_experiment(
    run_id_prefix: str,
    output_format: str = "excel",
    output_dir: Path = Path("data/outputs")
):
    """
    Load and export experiment results.
    
    Args:
        run_id_prefix: Run ID or prefix to filter sessions
        output_format: 'excel', 'json', or 'both'
        output_dir: Directory to save output
    """
    print(f"\nLoading experiment results for: {run_id_prefix}")
    
    # Load sessions
    session_data = await load_experiment_sessions(run_id_prefix)
    
    if not session_data:
        print(f"No sessions found for run_id: {run_id_prefix}")
        return
    
    print(f"Found {len(session_data)} sessions")
    
    # Aggregate
    rows = aggregate_results(session_data)
    print(f"Aggregated {len(rows)} question rows")
    
    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Export
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    if output_format in ["excel", "both"]:
        output_path = output_dir / f"experiment_{run_id_prefix}_{timestamp}.xlsx"
        export_to_excel(rows, output_path)
    
    if output_format in ["json", "both"]:
        output_path = output_dir / f"experiment_{run_id_prefix}_{timestamp}.json"
        export_to_json(rows, output_path)


def main():
    """CLI entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Export experiment results to Excel/JSON"
    )
    
    parser.add_argument(
        "run_id",
        help="Run ID or prefix to export"
    )
    parser.add_argument(
        "--format",
        choices=["excel", "json", "both"],
        default="excel",
        help="Output format (default: excel)"
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("data/outputs"),
        help="Output directory (default: data/outputs)"
    )
    
    args = parser.parse_args()
    
    asyncio.run(export_experiment(
        args.run_id,
        args.format,
        args.output_dir
    ))


if __name__ == "__main__":
    main()
