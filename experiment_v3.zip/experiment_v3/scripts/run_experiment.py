#!/usr/bin/env python3
"""
Experiment Runner - Complete Pipeline

Runs experiments across all configurations and tracks results.
"""

import asyncio
import sys
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any
import json

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from schemas import get_all_configs, ExperimentState
from pipeline import run_experiment, parse_and_validate_plan
from loaders import load_seed_questions


class ExperimentResults:
    """Tracks results across multiple experiment runs."""
    
    def __init__(self, run_id: str):
        self.run_id = run_id
        self.results = []
    
    def add_result(
        self,
        seed_question: str,
        config_name: str,
        session_id: str,
        state: ExperimentState,
        success: bool,
        error: Optional[str] = None
    ):
        """Add a single result."""
        
        plan = parse_and_validate_plan(state) if success else None
        
        result = {
            "run_id": self.run_id,
            "seed_question": seed_question,
            "config_name": config_name,
            "session_id": session_id,
            "generator_type": state.generator_type,
            "success": success,
            "error": error,
            "num_questions": len(plan.questions) if plan else 0,
            "num_genie_results": len(state.genie_results) if state.genie_results else 0,
            "timestamp": state.timestamp,
            "model": state.model
        }
        
        self.results.append(result)
    
    def summary(self) -> Dict[str, Any]:
        """Get summary statistics."""
        total = len(self.results)
        successful = sum(1 for r in self.results if r["success"])
        
        return {
            "run_id": self.run_id,
            "total_runs": total,
            "successful": successful,
            "failed": total - successful,
            "results": self.results
        }
    
    def save_json(self, output_dir: Path = Path("data/outputs")):
        """Save results to JSON file."""
        output_dir.mkdir(parents=True, exist_ok=True)
        
        output_file = output_dir / f"results_{self.run_id}.json"
        
        with open(output_file, 'w') as f:
            json.dump(self.summary(), f, indent=2)
        
        return output_file


async def run_single_seed(
    seed_question: str,
    config_names: Optional[List[str]] = None,
    run_id: Optional[str] = None,
    run_genie: bool = True
) -> ExperimentResults:
    """
    Run experiment on a single seed question across configs.
    
    Args:
        seed_question: The seed question
        config_names: Optional list of configs to run (default: all)
        run_id: Optional run ID (generated if not provided)
        run_genie: Whether to run mock Genie processing
    
    Returns:
        ExperimentResults with all results
    """
    if not run_id:
        run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Get configs
    all_configs = get_all_configs()
    if config_names:
        configs = {k: v for k, v in all_configs.items() if k in config_names}
    else:
        configs = all_configs
    
    print(f"\n{'='*70}")
    print(f"Question Generation Experiment")
    print(f"{'='*70}")
    print(f"Run ID: {run_id}")
    print(f"Seed: {seed_question}")
    print(f"Configs: {len(configs)}")
    print(f"Genie Processing: {'Enabled' if run_genie else 'Disabled'}")
    print(f"{'='*70}\n")
    
    results = ExperimentResults(run_id)
    
    for config_name, config in configs.items():
        print(f"Running {config_name}... ", end="", flush=True)
        
        try:
            session_id, state = await run_experiment(
                seed_question=seed_question,
                config=config,
                run_id=run_id,
                run_genie=run_genie
            )
            
            results.add_result(
                seed_question=seed_question,
                config_name=config_name,
                session_id=session_id,
                state=state,
                success=True
            )
            
            plan = await parse_and_validate_plan(state)
            num_questions = len(plan.questions) if plan else 0
            num_genie = len(state.genie_results) if state.genie_results else 0
            
            print(f"✓ ({num_questions} questions, {num_genie} genie results)")
            
        except Exception as e:
            # Still add result with error
            results.add_result(
                seed_question=seed_question,
                config_name=config_name,
                session_id="",
                state=ExperimentState(
                    seed_question=seed_question,
                    run_id=run_id,
                    config_name=config_name
                ),
                success=False,
                error=str(e)
            )
            print(f"✗ Error: {e}")
    
    # Print summary
    print(f"\n{'='*70}")
    print("Summary")
    print(f"{'='*70}")
    
    summary = results.summary()
    print(f"Total runs: {summary['total_runs']}")
    print(f"Successful: {summary['successful']}")
    print(f"Failed: {summary['failed']}")
    
    if summary['failed'] > 0:
        print("\nFailed runs:")
        for r in summary['results']:
            if not r['success']:
                print(f"  {r['config_name']}: {r['error']}")
    
    # Save results
    output_file = results.save_json()
    print(f"\nResults saved to: {output_file}")
    print(f"Run ID: {run_id}")
    print(f"{'='*70}\n")
    
    return results


async def run_all_seeds(
    config_names: Optional[List[str]] = None,
    run_genie: bool = True
) -> List[ExperimentResults]:
    """
    Run experiment on all seed questions from test_seeds.json.
    
    Args:
        config_names: Optional list of configs to run
        run_genie: Whether to run mock Genie processing
    
    Returns:
        List of ExperimentResults, one per seed
    """
    seeds = load_seed_questions()
    
    print(f"\n{'='*70}")
    print(f"Running {len(seeds)} seed questions")
    print(f"{'='*70}\n")
    
    all_results = []
    run_id_base = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    for i, seed_data in enumerate(seeds, 1):
        print(f"\n[{i}/{len(seeds)}] {seed_data['id']}: {seed_data['seed_question']}")
        
        results = await run_single_seed(
            seed_question=seed_data['seed_question'],
            config_names=config_names,
            run_id=f"{run_id_base}_seed{i}",
            run_genie=run_genie
        )
        
        all_results.append(results)
    
    # Overall summary
    print(f"\n{'='*70}")
    print("OVERALL SUMMARY")
    print(f"{'='*70}")
    
    total_runs = sum(r.summary()['total_runs'] for r in all_results)
    total_successful = sum(r.summary()['successful'] for r in all_results)
    
    print(f"Seeds processed: {len(seeds)}")
    print(f"Total runs: {total_runs}")
    print(f"Successful: {total_successful}/{total_runs}")
    print(f"{'='*70}\n")
    
    return all_results


def main():
    """CLI entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Run question generation experiment"
    )
    
    parser.add_argument(
        "question",
        nargs="?",
        help="Single seed question (or use --all-seeds)"
    )
    parser.add_argument(
        "--all-seeds",
        action="store_true",
        help="Run all seeds from test_seeds.json"
    )
    parser.add_argument(
        "--configs",
        nargs="+",
        help="Specific configs to run (default: all)"
    )
    parser.add_argument(
        "--no-genie",
        action="store_true",
        help="Skip Genie processing"
    )
    parser.add_argument(
        "--list-configs",
        action="store_true",
        help="List available configurations"
    )
    
    args = parser.parse_args()
    
    # List configs
    if args.list_configs:
        configs = get_all_configs()
        print("\nAvailable Configurations:")
        for name, config in configs.items():
            cc = config.context_config
            context = []
            if cc.sml_grounding: context.append("SML")
            if cc.persona_info: context.append("Persona")
            if cc.pattern_library: context.append("Patterns")
            if cc.few_shot_examples: context.append("Examples")
            
            print(f"  {name}: {', '.join(context) if context else 'No context (baseline)'}")
        return
    
    # Run experiments
    run_genie = not args.no_genie
    
    if args.all_seeds:
        asyncio.run(run_all_seeds(args.configs, run_genie))
    elif args.question:
        asyncio.run(run_single_seed(args.question, args.configs, run_genie=run_genie))
    else:
        parser.print_help()
        print("\nExamples:")
        print('  python scripts/run_experiment.py "Why is margin down?"')
        print('  python scripts/run_experiment.py --all-seeds')
        print('  python scripts/run_experiment.py "Why is margin down?" --configs baseline full_context')
        print('  python scripts/run_experiment.py --all-seeds --no-genie')


if __name__ == "__main__":
    main()
