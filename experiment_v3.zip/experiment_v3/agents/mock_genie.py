"""
Mock Genie Agent - Simulates Question Processing

A BaseAgent that takes questions and simulates processing them
through a "Genie" app, returning mock results.

This is for testing the end-to-end pipeline without a real Genie.
"""

import uuid
import random
from typing import AsyncGenerator, List
from google.adk.agents import BaseAgent
from google.adk.context import InvocationContext
from google.adk.events import Event, EventActions

from schemas import GenieResult, GenieStep, QuestionPlan


class MockGenieAgent(BaseAgent):
    """
    Mock Genie that processes questions and returns fake results.
    
    Reads from state:
        - question_plan: QuestionPlan with questions to process
    
    Writes to state:
        - genie_results: List[GenieResult] with mock processing results
    """
    
    def __init__(self):
        super().__init__(name="mock_genie")
    
    async def _run_async_impl(
        self, 
        ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        """Process questions through mock Genie."""
        
        # Get question plan from state
        plan_dict = ctx.session.state.get("question_plan")
        if not plan_dict:
            yield Event(
                author=self.name,
                content={"parts": [{"text": "No question plan in state"}]}
            )
            return
        
        plan = QuestionPlan(**plan_dict)
        
        # Process each question
        genie_results = []
        
        for i, question in enumerate(plan.questions, 1):
            # Simulate processing with multiple steps
            steps = self._generate_mock_steps(question.text)
            
            # Calculate total duration
            total_duration = sum(s.duration_ms for s in steps)
            
            # Create result
            result = GenieResult(
                question_text=question.text,
                session_id=f"genie_{uuid.uuid4().hex[:8]}",
                steps=[s.model_dump() for s in steps],
                total_duration_ms=total_duration,
                status="success"
            )
            
            genie_results.append(result.model_dump())
            
            # Emit progress event
            yield Event(
                author=self.name,
                content={"parts": [{"text": f"Processed question {i}/{len(plan.questions)}"}]}
            )
        
        # Emit final event with all results
        yield Event(
            author=self.name,
            content={"parts": [{"text": f"Processed {len(genie_results)} questions"}]},
            actions=EventActions(
                state_delta={
                    "genie_results": genie_results
                }
            )
        )
    
    def _generate_mock_steps(self, question_text: str) -> List[GenieStep]:
        """Generate mock processing steps for a question."""
        
        # Simulate 2-4 steps per question
        num_steps = random.randint(2, 4)
        steps = []
        
        # Common step types
        step_types = [
            ("parse", "Parsed question intent", (50, 150)),
            ("retrieve", "Retrieved relevant data", (100, 300)),
            ("analyze", "Performed analysis", (200, 500)),
            ("format", "Formatted results", (50, 100))
        ]
        
        selected_types = random.sample(step_types, num_steps)
        
        for i, (step_type, summary, duration_range) in enumerate(selected_types, 1):
            step = GenieStep(
                step_num=i,
                query=f"{step_type}: {question_text[:50]}...",
                result_summary=summary,
                status="success",
                duration_ms=random.uniform(*duration_range)
            )
            steps.append(step)
        
        return steps
