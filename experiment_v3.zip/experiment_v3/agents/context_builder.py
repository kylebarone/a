"""
Context Builder Agent - ADK Native

A BaseAgent that reads context config from state, loads appropriate
context sources, and updates state with a ContextPacket.

This is pure Python logic - no LLM involved.
"""

from typing import AsyncGenerator
from google.adk.agents import BaseAgent
from google.adk.context import InvocationContext
from google.adk.events import Event, EventActions

from schemas import ContextPacket, ContextConfig
from loaders import load_sml, load_persona, load_patterns, load_examples


class ContextBuilderAgent(BaseAgent):
    """
    Agent that builds context packets based on config in state.
    
    Reads from state:
        - context_config: ContextConfig with boolean flags
        - seed_question: For filtering SML
        - user_scope: User role/domain
    
    Writes to state:
        - context_packet: ContextPacket with loaded context
    """
    
    def __init__(self):
        super().__init__(name="context_builder")
    
    async def _run_async_impl(
        self, 
        ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        """Build context packet from state config."""
        
        # Read config from state
        context_config_dict = ctx.session.state.get("context_config", {})
        config = ContextConfig(**context_config_dict)
        
        seed_question = ctx.session.state.get("seed_question", "")
        
        # Extract keywords from seed for filtering
        keywords = [w for w in seed_question.lower().split() if len(w) > 3]
        
        # Build context packet
        packet_data = {}
        
        if config.sml_grounding:
            packet_data["sml"] = load_sml(filter_keywords=keywords)
        
        if config.persona_info:
            user_scope = ctx.session.state.get("user_scope", {})
            persona_name = user_scope.get("role", "merch_finance_analyst")
            if persona_name == "finance_analyst":
                persona_name = "merch_finance_analyst"
            packet_data["persona"] = load_persona(persona_name)
        
        if config.pattern_library:
            packet_data["patterns"] = load_patterns()
        
        if config.few_shot_examples:
            packet_data["examples"] = load_examples()
        
        # Create typed packet
        packet = ContextPacket(**packet_data, builder_type="simple")
        
        # Emit event with context packet in state
        yield Event(
            author=self.name,
            content={"parts": [{"text": f"Context built: {len(packet_data)} sources"}]},
            actions=EventActions(
                state_delta={
                    "context_packet": packet.model_dump()
                }
            )
        )
