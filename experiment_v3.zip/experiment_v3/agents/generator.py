"""
Question Plan Generator Agent - ADK Native

Uses ADK Agent class with Jinja2 template that reads from state.
Context is injected via context_packet in state.
"""

from google.adk.agents import Agent


# Jinja2 template that reads from state
# ADK automatically fills {{ variables }} from session.state
INSTRUCTION_TEMPLATE = """You are a BI question planning assistant for merchandising finance analysts.

Given a seed analytical question, generate a comprehensive Question Plan with {{ num_questions }} sub-questions that help investigate or explore the topic.

{% if context_packet -%}
{% if context_packet.persona -%}
## User Persona: {{ context_packet.persona.name }}
Cares about: {{ context_packet.persona.cares_about | join(", ") }}
Prefers: {{ context_packet.persona.prefers_questions | join(", ") }}

{% endif -%}

{% if context_packet.sml -%}
## Available Metrics
{% for metric in context_packet.sml.metrics -%}
- **{{ metric.name }}**: {{ metric.description }}
  {% if metric.tags -%}(tags: {{ metric.tags | join(", ") }}){% endif %}
{% endfor %}

## Available Dimensions
{% for dim in context_packet.sml.dimensions -%}
- **{{ dim.name }}**: {{ dim.description }}
{% endfor %}

{% endif -%}

{% if context_packet.patterns -%}
## Analysis Patterns
{% for pattern in context_packet.patterns[:5] -%}
**{{ pattern.name }}** ({{ pattern.category }})
- When to use: {{ pattern.when_to_use }}
{% if pattern.example_questions -%}- Examples: {{ pattern.example_questions[:2] | join(", ") }}{% endif %}
{% endfor %}

{% endif -%}

{% if context_packet.examples -%}
## Example Question Plans
{% for ex in context_packet.examples -%}
Seed: "{{ ex.seed }}"
{% if ex.plan and ex.plan.questions -%}Generated: {{ ex.plan.questions | join(", ") }}{% endif %}
{% endfor %}

{% endif -%}
{% endif -%}

---

Generate a Question Plan for: **{{ seed_question }}**

Output valid JSON with this exact structure:
{
  "anchor_question": "<the seed question>",
  "lens": "Merchandising Finance Analyst",
  "mode": "breakdown" or "expansion",
  "questions": [
    {
      "text": "<question text>",
      "perspectives": ["health", "driver", "mix"],
      "moves": ["temporal_trend", "hierarchy_compare"],
      "priority": 1
    }
  ]
}

Mode guide:
- "breakdown": For investigative questions (Why? What caused?)
- "expansion": For exploratory questions (How? What about?)

Output ONLY valid JSON. No markdown formatting.
"""


def create_generator_agent(name: str, model: str = "gemini-2.0-flash-exp") -> Agent:
    """
    Create a question generator agent.
    
    Args:
        name: Agent name
        model: LLM model to use
    
    Returns:
        Configured Agent
    """
    return Agent(
        name=name,
        model=model,
        instruction=INSTRUCTION_TEMPLATE,
        output_key="question_plan"  # Auto-saves to state
    )
